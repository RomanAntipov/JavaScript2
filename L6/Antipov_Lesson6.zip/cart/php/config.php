<?php

$products = array(
	1 => array(
		'id' => 1,
		'price' => 69,
		'name' => 'GTA 5',
	),
	2 => array(
		'id' => 2,
		'price' => 79,
		'name' => 'Far Cry 5',
	),
	3 => array(
		'id' => 3,
		'price' => 54,
		'name' => 'Fallout 4',
	),
	4 => array(
		'id' => 4,
		'price' => 47,
		'name' => 'Last Of Us',
	),
	5 => array(
		'id' => 5,
		'price' => 59,
		'name' => 'Uncharted 4',
	),
);
